import React, {Component} from 'react';


export default class Ad3 extends Component{

	render(){
   return(
		<section>
			Ad3
		</section>
	)
	}
}