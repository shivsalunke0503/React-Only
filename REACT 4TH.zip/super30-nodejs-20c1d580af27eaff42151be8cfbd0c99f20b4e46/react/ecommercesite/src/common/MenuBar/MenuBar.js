import React, {Component} from 'react';

export default class MenuBar extends Component{

	render(){
   return(
		<section>
			MenuBar
		</section>
	)
	}
}