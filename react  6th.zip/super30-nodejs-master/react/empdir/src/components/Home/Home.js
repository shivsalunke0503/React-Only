import React, {Component} from 'react';

export default class Home extends Component{

	render(){
		return(

	    	<div className="row">
				<div className="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<h1> Home Page </h1>
					<p> 
						Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum 
						Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum 
						Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum 
						Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum 
						Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum 
						Lorem Ipsum Lorem Ipsum Lorem Ipsum Lorem Ipsum 
					</p>
		    	</div>
		    </div>


		);
	}

} 