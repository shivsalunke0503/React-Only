import React from 'react';

import './PageNotFound.css';


export default function PageNotFound(){
        return (
                <div className="row">
                    <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <img src="images/pagenotfound.jpg" className="pagenotfound" alt="pagenotfound"/>
                    </div>
                </div>
        );
}



