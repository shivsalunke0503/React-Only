import React, {Component} from 'react';

export default class TopStrip extends Component{

	render(){
   return(
		<section>
			Top Strip
		</section>
	)
	}
}