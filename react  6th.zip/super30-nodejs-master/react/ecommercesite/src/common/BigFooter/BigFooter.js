import React, {Component} from 'react';


export default class BigFooter extends Component{

	render(){
   return(
		<section>
			BigFooter
		</section>
	)
	}
}