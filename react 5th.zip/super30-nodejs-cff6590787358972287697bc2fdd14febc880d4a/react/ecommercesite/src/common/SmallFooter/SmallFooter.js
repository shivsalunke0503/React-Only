import React, {Component} from 'react';



export default class SmallFooter extends Component{

	render(){
   return(
		<section>
			SmallFooter
		</section>
	)
	}
}