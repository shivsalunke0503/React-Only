import React from 'react';
import './Header.css';

function Header(){

	return(
		<header>
		
			<div className="row">
				<div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 headerBar">

				</div>
			</div>
		</header>
	);
}

export default Header;