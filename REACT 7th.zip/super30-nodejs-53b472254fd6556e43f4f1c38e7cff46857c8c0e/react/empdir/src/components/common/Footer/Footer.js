import React from 'react';
import './Footer.css';

function Footer(){

	return(
		<footer>
			<div className="row">
				<div className="col-lg-12 col-md-12 col-sm-12 col-xs-12 footerBar">

				</div>
			</div>
		</footer>
	);
}

export default Footer;