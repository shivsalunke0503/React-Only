import React, {Component} from 'react';


export default class AdmissionForm extends Component{

	render(){
		return(
			<div>
				Hello World from AdmissionForm!
			</div>
		);	
	}	
	
}


