import React, {Component} from 'react';


export default class Footer2 extends Component{

	render(){
		return(
			<div>
				Footer2
			</div>
		);	
	}	

}


