import React, {Component} from 'react';


export default class Footer1 extends Component{

	render(){
		return(
			<div>
				Footer1
			</div>
		);	
	}	
	
}


