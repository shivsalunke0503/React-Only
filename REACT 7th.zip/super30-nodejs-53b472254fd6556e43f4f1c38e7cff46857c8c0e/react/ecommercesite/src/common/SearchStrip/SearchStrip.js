import React, {Component} from 'react';


export default class SearchStrip extends Component{

	render(){
   return(
		<section>
			SearchStrip
		</section>
	)
	}
}