import React, {Component} from 'react';


export default class Ad2 extends Component{

	render(){
   return(
		<section>
			Ad2
		</section>
	)
	}
}