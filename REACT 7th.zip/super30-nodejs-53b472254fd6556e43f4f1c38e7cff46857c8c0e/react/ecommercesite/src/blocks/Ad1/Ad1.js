import React, {Component} from 'react';


export default class Ad1 extends Component{

	render(){
   return(
		return(
			<section>
				Ad1
			</section>
		)
	}
}